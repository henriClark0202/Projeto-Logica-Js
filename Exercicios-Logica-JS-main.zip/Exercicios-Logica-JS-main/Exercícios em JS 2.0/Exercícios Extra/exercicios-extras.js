// somar dois números
function soma() {
    let x = parseInt(prompt('Digite um numero'))
    let y = parseInt(prompt('Digite um numero'))
    let z = x + y

    alert(x + '+' + y + '=' + z)
}

// subtrair dois números
function subtracao() {
    let x = parseInt(prompt('Digite um numero'))
    let y = parseInt(prompt('Digite um numero'))
    let z = x - y

    alert(x + '-' + y + '=' + z)
}

// multiplicar dois números
function multiplicacao() {
    let x = parseInt(prompt('Digite um numero'))
    let y = parseInt(prompt('Digite um numero'))
    let z = x * y

    alert(x + '*' + y + '=' + z)
}

// dividir dois números
function divisao() {
    let x = parseFloat(prompt('Digite um numero'))
    let y = parseFloat(prompt('Digite um numero'))
    let z = x / y

    alert(x + '/' + y + '=' + z)
}
